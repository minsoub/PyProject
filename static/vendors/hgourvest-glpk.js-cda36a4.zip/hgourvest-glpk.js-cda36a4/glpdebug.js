function xassert(test){
    if (!test){
        throw new Error('assert');
    }
}

