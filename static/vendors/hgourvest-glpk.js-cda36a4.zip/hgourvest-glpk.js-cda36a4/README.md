# glpk.js

GNU Linear Programming Kit for Javascript

[Live demo][demo]
[demo]: http://hgourvest.github.io/glpk.js/
